CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    created_at DATETIME NOT NULL,
    role VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO customers (full_name, email, phone, created_at) VALUES
    ('Edzel Arce', 'edzelarce@gmail.com', '09216799439', '2026-09-17 09:00:00'),
    ('Nadine Carino', 'ccarino@gmail.com', '09195235035', '2026-09-17 09:05:00'),
    ('Jp Robes', 'jprobes@gmail.com', '09195062310', '2026-09-17 09:10:00'),
    ('Arby Puno', 'arbypuno@gmail.com', '09247882574', '2026-09-17 09:15:00'),
    ('Denzel Gavin', 'denzelgavin@gmail.com', '09255872685', '2026-09-17 09:20:00');

INSERT INTO users (username, full_name, created_at, role) VALUES
    ('admin01', 'Kim Cortez', '2026-09-17 09:00:00', 'Administrator'),
    ('cashier01', 'Ellimac Key', '2026-09-17 09:05:00', 'Cashier'),
    ('cashier02', 'Camille Ye', '2026-09-17 09:10:00', 'Cashier'),
    ('manager01', 'Thea Maine', '2026-09-17 09:15:00', 'Store Manager'),
    ('staff01', 'Ali Rain', '2026-09-17 09:20:00', 'Sales Staff');
